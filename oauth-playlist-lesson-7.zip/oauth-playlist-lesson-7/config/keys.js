// add this file to .gitignore

module.exports = {
        google: {
            clientID: 'enter your client id here',
            clientSecret: 'enter your client secret here'
        }
};
