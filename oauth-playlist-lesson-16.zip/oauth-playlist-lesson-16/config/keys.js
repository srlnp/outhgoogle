// add this file to .gitignore

module.exports = {
        google: {
            clientID: '616581710231-3gh4r5mnbeadi0r9h1gbvk844kbir61o.apps.googleusercontent.com',
            clientSecret: 'y3kKg0rZlk3WhE5u-A5aHwsD'
        },
        mongodb: {
            dbURI: 'mongodb://iamshaunjp:test6@ds151024.mlab.com:51024/oauth-test'
        },
        session: {
            cookieKey: 'thenetninjaisawesomeiguess'
        }
};
